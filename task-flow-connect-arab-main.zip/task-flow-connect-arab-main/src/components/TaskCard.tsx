
import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Edit, MoreVertical, Trash2, UserPlus, ClockIcon, CheckCircle } from 'lucide-react';
import { useApp, Task } from '@/context/AppContext';
import { formatDistanceToNow } from 'date-fns';
import { ar } from 'date-fns/locale';

interface TaskCardProps {
  task: Task;
  onEdit?: (task: Task) => void;
  onAssign?: (task: Task) => void;
  onPostpone?: (task: Task) => void;
  isAdmin?: boolean;
}

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case 'بسيطة':
      return 'bg-blue-500';
    case 'متوسطة':
      return 'bg-amber-500';
    case 'ضرورية':
      return 'bg-red-500';
    default:
      return 'bg-gray-500';
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case 'مكتملة':
      return 'bg-green-500';
    case 'قيد التنفيذ':
      return 'bg-blue-500';
    case 'متأخرة':
      return 'bg-red-500';
    case 'مؤجلة':
      return 'bg-amber-500';
    default:
      return 'bg-gray-500';
  }
};

const TaskCard: React.FC<TaskCardProps> = ({ 
  task, 
  onEdit, 
  onAssign, 
  onPostpone,
  isAdmin = false 
}) => {
  const { getUserById, completeTask, deleteTask, currentUser } = useApp();
  const assignedTo = getUserById(task.assignedTo);
  const createdBy = getUserById(task.createdBy);
  
  const isOwnTask = currentUser?.id === task.assignedTo;
  const canComplete = isOwnTask && task.status !== 'مكتملة';
  const canEdit = isAdmin || currentUser?.id === task.createdBy;
  const dueDate = new Date(task.dueDate);
  const isOverdue = dueDate < new Date() && task.status !== 'مكتملة';
  
  const handleCompleteTask = () => {
    completeTask(task.id);
  };

  const handleDeleteTask = () => {
    if (window.confirm('هل أنت متأكد من حذف هذه المهمة؟')) {
      deleteTask(task.id);
    }
  };

  return (
    <Card className={`${isOverdue ? 'border-red-500' : ''}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-lg">{task.title}</CardTitle>
            <CardDescription className="mt-1">
              بواسطة: {createdBy?.name || 'غير معروف'}
            </CardDescription>
          </div>
          
          <div className="flex space-x-2">
            <Badge className={`${getPriorityColor(task.priority)} ml-2`}>
              {task.priority}
            </Badge>
            
            <Badge className={getStatusColor(task.status)}>
              {task.status}
            </Badge>
            
            {canEdit && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  {onEdit && (
                    <DropdownMenuItem onClick={() => onEdit(task)}>
                      <Edit className="ms-2 h-4 w-4" />
                      تعديل
                    </DropdownMenuItem>
                  )}
                  
                  {onAssign && (
                    <DropdownMenuItem onClick={() => onAssign(task)}>
                      <UserPlus className="ms-2 h-4 w-4" />
                      إسناد لمستخدم آخر
                    </DropdownMenuItem>
                  )}
                  
                  <DropdownMenuItem onClick={handleDeleteTask} className="text-red-500">
                    <Trash2 className="ms-2 h-4 w-4" />
                    حذف
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-2">
        <p className="text-sm mb-4">{task.description}</p>
        
        <div className="flex flex-col space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">المسؤول:</span>
            <span>{assignedTo?.name || 'غير معروف'}</span>
          </div>
          
          <div className="flex justify-between">
            <span className="text-muted-foreground">تاريخ التنفيذ:</span>
            <span className={isOverdue ? 'text-red-500 font-bold' : ''}>
              {dueDate.toLocaleDateString('ar-EG')} - {dueDate.toLocaleTimeString('ar-EG', { 
                hour: '2-digit', 
                minute: '2-digit' 
              })}
            </span>
          </div>
          
          {isOverdue && task.status !== 'مكتملة' && (
            <div className="flex justify-between text-red-500">
              <span>متأخرة بمدة:</span>
              <span>
                {formatDistanceToNow(dueDate, { locale: ar, addSuffix: true })}
              </span>
            </div>
          )}
          
          {task.status === 'مؤجلة' && task.postponeReason && (
            <div className="mt-2 p-2 bg-muted rounded-md">
              <span className="block text-muted-foreground">سبب التأجيل:</span>
              <span>{task.postponeReason}</span>
            </div>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between pt-2">
        {canComplete && (
          <Button 
            onClick={handleCompleteTask} 
            variant="outline" 
            size="sm" 
            className="text-green-500 border-green-500 hover:bg-green-50"
          >
            <CheckCircle className="ms-2 h-4 w-4" />
            إكمال المهمة
          </Button>
        )}
        
        {onPostpone && isOwnTask && task.status !== 'مكتملة' && (
          <Button 
            onClick={() => onPostpone(task)} 
            variant="outline" 
            size="sm"
            className="text-amber-500 border-amber-500 hover:bg-amber-50"
          >
            <ClockIcon className="ms-2 h-4 w-4" />
            طلب تأجيل
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default TaskCard;
