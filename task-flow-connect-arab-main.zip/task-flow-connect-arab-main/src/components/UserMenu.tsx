
import React from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useApp, Task } from '@/context/AppContext';
import { CheckCircle2, AlertCircle, User, LogOut, Trash2, BellOff } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const UserMenu = () => {
  const { currentUser, tasks, logout } = useApp();
  const navigate = useNavigate();
  
  if (!currentUser) return null;
  
  // Calculate task stats
  const completedTasks = tasks.filter(
    task => task.assignedTo === currentUser.id && task.status === 'مكتملة'
  );
  
  const pendingTasks = tasks.filter(
    task => task.assignedTo === currentUser.id && task.status === 'قيد التنفيذ'
  );
  
  const lateTasks = tasks.filter(
    task => task.assignedTo === currentUser.id && task.status === 'متأخرة'
  );
  
  const postponedTasks = tasks.filter(
    task => task.assignedTo === currentUser.id && task.status === 'مؤجلة'
  );

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className="flex items-center space-x-2 bg-transparent hover:bg-primary/10 p-2 rounded-full">
          <span className="text-right font-medium ms-2">{currentUser.name}</span>
          <Avatar>
            <AvatarFallback className="bg-primary text-primary-foreground">
              {currentUser.name.charAt(0)}
            </AvatarFallback>
          </Avatar>
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>حسابي</DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        <DropdownMenuItem onClick={() => navigate('/profile')}>
          <User className="ms-2 h-4 w-4" />
          <span>الملف الشخصي</span>
        </DropdownMenuItem>
        
        <DropdownMenuSeparator />
        <DropdownMenuLabel>المهام</DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        <DropdownMenuItem onClick={() => navigate('/daily-tasks', { state: { filter: 'completed' } })}>
          <CheckCircle2 className="ms-2 h-4 w-4 text-green-500" />
          <span>المهام المنجزة</span>
          <span className="ms-auto bg-muted text-muted-foreground rounded-full h-6 w-6 flex items-center justify-center text-xs">
            {completedTasks.length}
          </span>
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={() => navigate('/daily-tasks', { state: { filter: 'pending' } })}>
          <span className="ms-2 h-4 w-4 text-blue-500">⏳</span>
          <span>المهام قيد التنفيذ</span>
          <span className="ms-auto bg-muted text-muted-foreground rounded-full h-6 w-6 flex items-center justify-center text-xs">
            {pendingTasks.length}
          </span>
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={() => navigate('/daily-tasks', { state: { filter: 'late' } })}>
          <AlertCircle className="ms-2 h-4 w-4 text-red-500" />
          <span>المهام المتأخرة</span>
          <span className="ms-auto bg-muted text-muted-foreground rounded-full h-6 w-6 flex items-center justify-center text-xs">
            {lateTasks.length}
          </span>
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={() => navigate('/postponed-tasks')}>
          <span className="ms-2 h-4 w-4 text-amber-500">⏱️</span>
          <span>المهام المؤجلة</span>
          <span className="ms-auto bg-muted text-muted-foreground rounded-full h-6 w-6 flex items-center justify-center text-xs">
            {postponedTasks.length}
          </span>
        </DropdownMenuItem>
        
        <DropdownMenuSeparator />
        <DropdownMenuLabel>الإشعارات</DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        <DropdownMenuItem onClick={() => navigate('/notifications')}>
          <span className="ms-2 h-4 w-4 text-red-500">⚠️</span>
          <span>التحذيرات من الإدارة</span>
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={() => navigate('/notifications')}>
          <BellOff className="ms-2 h-4 w-4 text-red-500" />
          <span>العقوبات من الإدارة</span>
        </DropdownMenuItem>
        
        <DropdownMenuSeparator />
        
        <DropdownMenuItem 
          onClick={() => navigate('/delete-account')}
          className="text-red-500 focus:text-red-500"
        >
          <Trash2 className="ms-2 h-4 w-4" />
          <span>إزالة حساب المستخدم</span>
        </DropdownMenuItem>
        
        <DropdownMenuItem onClick={logout}>
          <LogOut className="ms-2 h-4 w-4" />
          <span>تسجيل الخروج</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default UserMenu;
