
import React from 'react';
import TaskCard from '@/components/TaskCard';
import { Task } from '@/context/AppContext';

export interface TaskCardWrapperProps {
  task: Task;
  assigneeName: string;
  creatorName: string;
}

const TaskCardWrapper: React.FC<TaskCardWrapperProps> = ({ 
  task, 
  assigneeName, 
  creatorName 
}) => {
  return (
    <TaskCard 
      task={task} 
      // Map the props correctly according to what TaskCard expects
      // This wrapper allows us to adapt the interface without modifying the original component
    />
  );
};

export default TaskCardWrapper;
