
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { 
  LayoutDashboard, 
  ListTodo, 
  Calendar, 
  MessageSquare, 
  Clock, 
  Award, 
  Settings,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useApp } from '@/context/AppContext';

interface SidebarProps {
  isCollapsed: boolean;
  toggleSidebar: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isCollapsed, toggleSidebar }) => {
  const location = useLocation();
  const { currentUser } = useApp();
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const menuItems = [
    {
      title: 'لوحة التحكم',
      path: '/',
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      title: 'المهام اليومية',
      path: '/daily-tasks',
      icon: <ListTodo className="h-5 w-5" />,
    },
    {
      title: 'جدول المهام',
      path: '/task-schedule',
      icon: <Calendar className="h-5 w-5" />,
    },
    {
      title: 'المحادثات',
      path: '/messages',
      icon: <MessageSquare className="h-5 w-5" />,
    },
    {
      title: 'المهام المؤجلة',
      path: '/postponed-tasks',
      icon: <Clock className="h-5 w-5" />,
    },
    {
      title: 'الإنجازات',
      path: '/achievements',
      icon: <Award className="h-5 w-5" />,
    },
    {
      title: 'الإعدادات',
      path: '/settings',
      icon: <Settings className="h-5 w-5" />,
    },
  ];

  return (
    <div className={cn(
      "fixed top-0 right-0 z-40 h-screen transition-width duration-300 ease-in-out bg-sidebar text-sidebar-foreground border-l border-sidebar-border",
      isCollapsed ? "w-16" : "w-64"
    )}>
      <div className="flex flex-col h-full">
        {/* Sidebar Header */}
        <div className="p-4 border-b border-sidebar-border">
          <div className="flex items-center justify-between">
            {!isCollapsed && (
              <h2 className="text-xl font-bold">نظام المهام</h2>
            )}
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleSidebar}
              className="text-sidebar-foreground hover:text-white hover:bg-sidebar-accent"
            >
              {isCollapsed ? <ChevronLeft className="h-5 w-5" /> : <ChevronRight className="h-5 w-5" />}
            </Button>
          </div>
        </div>
        
        {/* User Info */}
        {!isCollapsed && currentUser && (
          <div className="p-4 border-b border-sidebar-border">
            <div className="text-center">
              <div className="h-16 w-16 rounded-full bg-sidebar-primary mx-auto flex items-center justify-center">
                <span className="text-lg font-bold text-sidebar-primary-foreground">
                  {currentUser.name.charAt(0)}
                </span>
              </div>
              <h3 className="mt-2 font-medium">{currentUser.name}</h3>
              <p className="text-sm text-sidebar-foreground/70">{currentUser.role === 'admin' ? 'مدير النظام' : 'مستخدم'}</p>
            </div>
          </div>
        )}
        
        {/* Menu Items */}
        <nav className="flex-1 p-4 overflow-y-auto">
          <ul className="space-y-2">
            {menuItems.map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={cn(
                    "flex items-center p-2 rounded-md transition-colors",
                    isActive(item.path)
                      ? "bg-sidebar-primary text-sidebar-primary-foreground"
                      : "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  )}
                >
                  <span className="me-2 flex-shrink-0">{item.icon}</span>
                  {!isCollapsed && <span>{item.title}</span>}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        
        {/* Footer */}
        <div className="p-4 border-t border-sidebar-border text-center">
          {!isCollapsed ? (
            <p className="text-xs text-sidebar-foreground/70">© 2025 نظام إدارة المهام</p>
          ) : (
            <p className="text-xs">©</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
