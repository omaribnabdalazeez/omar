
import React, { useState } from 'react';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { toast } from '@/components/ui/sonner';
import { useApp } from '@/context/AppContext';
import { TaskPriority } from '@/context/AppContext';

interface AddTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const AddTaskModal: React.FC<AddTaskModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, users, addTask } = useApp();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [dueTime, setDueTime] = useState('');
  const [priority, setPriority] = useState<TaskPriority>('متوسطة');
  const [assignedTo, setAssignedTo] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentUser) {
      toast.error('يجب تسجيل الدخول لإضافة مهمة جديدة');
      return;
    }
    
    // Make sure assignedTo is a valid user
    const assignedUser = users.find(u => u.id === assignedTo);
    if (!assignedUser) {
      toast.error('المستخدم المطلوب تنفيذ المهمة غير موجود');
      return;
    }
    
    // Combine date and time
    const dateTimeString = `${dueDate}T${dueTime}:00`;
    const dueDateTime = new Date(dateTimeString);
    
    setIsSubmitting(true);
    
    // Call addTask function from context
    addTask({
      title,
      description,
      dueDate: dueDateTime,
      createdBy: currentUser.id,
      assignedTo,
      priority
    });
    
    setIsSubmitting(false);
    onClose();
    
    // Reset form
    setTitle('');
    setDescription('');
    setDueDate('');
    setDueTime('');
    setPriority('متوسطة');
    setAssignedTo('');
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-right">إضافة مهمة جديدة</DialogTitle>
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute left-4 top-4" 
            onClick={onClose}
          >
            <X className="h-4 w-4" />
          </Button>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="title" className="text-right block text-sm font-medium">
              عنوان المهمة
            </label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="أدخل عنوان المهمة"
              required
              className="text-right"
            />
          </div>
          
          <div className="space-y-2">
            <label htmlFor="description" className="text-right block text-sm font-medium">
              وصف المهمة
            </label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="أدخل وصف المهمة"
              required
              className="text-right"
              rows={3}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label htmlFor="dueDate" className="text-right block text-sm font-medium">
                تاريخ الاستحقاق
              </label>
              <Input
                id="dueDate"
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                required
                className="text-right"
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="dueTime" className="text-right block text-sm font-medium">
                وقت الاستحقاق
              </label>
              <Input
                id="dueTime"
                type="time"
                value={dueTime}
                onChange={(e) => setDueTime(e.target.value)}
                required
                className="text-right"
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <label htmlFor="priority" className="text-right block text-sm font-medium">
              الأولوية
            </label>
            <Select 
              value={priority} 
              onValueChange={(value) => setPriority(value as TaskPriority)}
            >
              <SelectTrigger id="priority" className="text-right">
                <SelectValue placeholder="اختر الأولوية" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="بسيطة">بسيطة</SelectItem>
                <SelectItem value="متوسطة">متوسطة</SelectItem>
                <SelectItem value="ضرورية">ضرورية</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <label htmlFor="assignedTo" className="text-right block text-sm font-medium">
              تعيين إلى
            </label>
            <Select 
              value={assignedTo} 
              onValueChange={setAssignedTo}
            >
              <SelectTrigger id="assignedTo" className="text-right">
                <SelectValue placeholder="اختر المستخدم" />
              </SelectTrigger>
              <SelectContent>
                {users.map(user => (
                  <SelectItem key={user.id} value={user.id}>{user.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <DialogFooter>
            <Button 
              type="submit" 
              className="w-full" 
              disabled={isSubmitting || !currentUser}
            >
              {isSubmitting ? 'جاري الإضافة...' : 'إضافة المهمة'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AddTaskModal;
