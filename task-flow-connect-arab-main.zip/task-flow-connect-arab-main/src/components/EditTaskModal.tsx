
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useApp, Task, TaskPriority, TaskStatus } from '@/context/AppContext';
import { toast } from '@/components/ui/sonner';

interface EditTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  task: Task | null;
}

const EditTaskModal: React.FC<EditTaskModalProps> = ({ isOpen, onClose, task }) => {
  const { users, updateTask } = useApp();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [dueTime, setDueTime] = useState('');
  const [priority, setPriority] = useState<TaskPriority>('متوسطة');
  const [status, setStatus] = useState<TaskStatus>('قيد التنفيذ');
  const [assignedToId, setAssignedToId] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Update form fields when task changes
  useEffect(() => {
    if (task) {
      setTitle(task.title);
      setDescription(task.description);
      
      const date = new Date(task.dueDate);
      setDueDate(date.toISOString().split('T')[0]);
      setDueTime(`${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`);
      
      setPriority(task.priority);
      setStatus(task.status);
      setAssignedToId(task.assignedTo);
    }
  }, [task]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!task) {
      toast.error('خطأ: لم يتم تحديد المهمة');
      return;
    }
    
    if (!dueDate || !dueTime) {
      toast.error('الرجاء تحديد التاريخ والوقت');
      return;
    }
    
    if (!assignedToId) {
      toast.error('الرجاء اختيار الشخص المسؤول');
      return;
    }
    
    setIsLoading(true);
    
    // Check if assigned user exists
    const assignedUser = users.find(user => user.id === assignedToId);
    if (!assignedUser) {
      toast.error('المستخدم المطلوب غير موجود');
      setIsLoading(false);
      return;
    }
    
    // Create due date from date and time inputs
    const [year, month, day] = dueDate.split('-').map(Number);
    const [hours, minutes] = dueTime.split(':').map(Number);
    const dueDateObj = new Date(year, month - 1, day, hours, minutes);
    
    // Update task
    updateTask(task.id, {
      title,
      description,
      dueDate: dueDateObj,
      assignedTo: assignedToId,
      priority,
      status,
    });
    
    // Close modal
    onClose();
    setIsLoading(false);
  };

  // Format today's date as YYYY-MM-DD for the date input min attribute
  const today = new Date().toISOString().split('T')[0];

  if (!task) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-center text-xl font-bold">تعديل المهمة</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="edit-title">عنوان المهمة</Label>
            <Input
              id="edit-title"
              placeholder="أدخل عنوان المهمة"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="edit-description">تفاصيل المهمة</Label>
            <Textarea
              id="edit-description"
              placeholder="أدخل وصف تفصيلي للمهمة"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
              rows={3}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-due-date">تاريخ التنفيذ</Label>
              <Input
                id="edit-due-date"
                type="date"
                min={today}
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="edit-due-time">وقت التنفيذ</Label>
              <Input
                id="edit-due-time"
                type="time"
                value={dueTime}
                onChange={(e) => setDueTime(e.target.value)}
                required
              />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-priority">أهمية المهمة</Label>
              <Select 
                value={priority} 
                onValueChange={(value) => setPriority(value as TaskPriority)}
              >
                <SelectTrigger id="edit-priority">
                  <SelectValue placeholder="اختر مستوى الأهمية" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="بسيطة">بسيطة</SelectItem>
                  <SelectItem value="متوسطة">متوسطة</SelectItem>
                  <SelectItem value="ضرورية">ضرورية</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="edit-status">حالة المهمة</Label>
              <Select 
                value={status} 
                onValueChange={(value) => setStatus(value as TaskStatus)}
              >
                <SelectTrigger id="edit-status">
                  <SelectValue placeholder="اختر حالة المهمة" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="قيد التنفيذ">قيد التنفيذ</SelectItem>
                  <SelectItem value="مكتملة">مكتملة</SelectItem>
                  <SelectItem value="متأخرة">متأخرة</SelectItem>
                  <SelectItem value="مؤجلة">مؤجلة</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="edit-assigned-to">الشخص المسؤول</Label>
            <Select 
              value={assignedToId} 
              onValueChange={setAssignedToId}
            >
              <SelectTrigger id="edit-assigned-to">
                <SelectValue placeholder="اختر الشخص المسؤول" />
              </SelectTrigger>
              <SelectContent>
                {users.map(user => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <DialogFooter className="mt-6">
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? 'جاري التحديث...' : 'تحديث المهمة'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EditTaskModal;
