
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useApp, Task } from '@/context/AppContext';
import { toast } from '@/components/ui/sonner';

interface AssignTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  task: Task | null;
}

const AssignTaskModal: React.FC<AssignTaskModalProps> = ({ isOpen, onClose, task }) => {
  const { users, assignTaskToUser, getUserById } = useApp();
  
  const [assignedToId, setAssignedToId] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Reset selection when task changes
  React.useEffect(() => {
    if (task) {
      setAssignedToId('');
    }
  }, [task]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!task) {
      toast.error('خطأ: لم يتم تحديد المهمة');
      return;
    }
    
    if (!assignedToId) {
      toast.error('الرجاء اختيار الشخص المسؤول');
      return;
    }
    
    // Don't reassign to the same person
    if (assignedToId === task.assignedTo) {
      toast.error('المهمة مسندة بالفعل إلى هذا الشخص');
      return;
    }
    
    setIsLoading(true);
    
    // Check if assigned user exists
    const assignedUser = users.find(user => user.id === assignedToId);
    if (!assignedUser) {
      toast.error('المستخدم المطلوب غير موجود');
      setIsLoading(false);
      return;
    }
    
    // Assign task
    assignTaskToUser(task.id, assignedToId);
    
    // Reset and close
    setAssignedToId('');
    setIsLoading(false);
    onClose();
  };

  if (!task) return null;

  // Get current assignee name
  const currentAssignee = getUserById(task.assignedTo);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="text-center text-xl font-bold">إسناد المهمة لمستخدم آخر</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>المهمة</Label>
            <div className="p-3 bg-muted rounded-md">{task.title}</div>
          </div>
          
          <div className="space-y-2">
            <Label>المسؤول الحالي</Label>
            <div className="p-3 bg-muted rounded-md">{currentAssignee?.name || 'غير معروف'}</div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="new-assignee">المسؤول الجديد</Label>
            <Select 
              value={assignedToId} 
              onValueChange={setAssignedToId}
            >
              <SelectTrigger id="new-assignee">
                <SelectValue placeholder="اختر الشخص المسؤول" />
              </SelectTrigger>
              <SelectContent>
                {users
                  .filter(user => user.id !== task.assignedTo) // Don't show current assignee
                  .map(user => (
                    <SelectItem key={user.id} value={user.id}>
                      {user.name}
                    </SelectItem>
                  ))
                }
              </SelectContent>
            </Select>
          </div>
          
          <DialogFooter className="mt-6">
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? 'جاري الإسناد...' : 'إسناد المهمة'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AssignTaskModal;
