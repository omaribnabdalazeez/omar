
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useApp, Task } from '@/context/AppContext';
import { toast } from '@/components/ui/sonner';

interface PostponeTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
  task: Task | null;
}

const PostponeTaskModal: React.FC<PostponeTaskModalProps> = ({ isOpen, onClose, task }) => {
  const { postponeTask, getUserById } = useApp();
  
  const [reason, setReason] = useState('');
  const [newDate, setNewDate] = useState('');
  const [newTime, setNewTime] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Reset form on open
  React.useEffect(() => {
    if (isOpen && task) {
      setReason('');
      
      // Set default new date to tomorrow
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      setNewDate(tomorrow.toISOString().split('T')[0]);
      
      // Set default time
      setNewTime('12:00');
    }
  }, [isOpen, task]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!task) {
      toast.error('خطأ: لم يتم تحديد المهمة');
      return;
    }
    
    if (!newDate || !newTime) {
      toast.error('الرجاء تحديد التاريخ والوقت الجديد');
      return;
    }
    
    setIsLoading(true);
    
    // Create new date from inputs
    const [year, month, day] = newDate.split('-').map(Number);
    const [hours, minutes] = newTime.split(':').map(Number);
    const postponedUntil = new Date(year, month - 1, day, hours, minutes);
    
    // Postpone task
    postponeTask(task.id, reason, postponedUntil);
    
    // Reset and close
    setReason('');
    setNewDate('');
    setNewTime('');
    setIsLoading(false);
    onClose();
  };

  if (!task) return null;

  // Get creator and assignee names
  const creator = getUserById(task.createdBy);
  const assignee = getUserById(task.assignedTo);

  // Format today's date as YYYY-MM-DD for the date input min attribute
  const today = new Date().toISOString().split('T')[0];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-center text-xl font-bold">طلب تأجيل المهمة</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>المهمة</Label>
            <div className="p-3 bg-muted rounded-md">{task.title}</div>
          </div>
          
          <div className="space-y-2">
            <Label>تاريخ الاستحقاق الحالي</Label>
            <div className="p-3 bg-muted rounded-md">
              {new Date(task.dueDate).toLocaleDateString('ar-EG')} {' - '}
              {new Date(task.dueDate).toLocaleTimeString('ar-EG', {
                hour: '2-digit',
                minute: '2-digit'
              })}
            </div>
          </div>
          
          <div className="space-y-2">
            <Label>المسؤول</Label>
            <div className="p-3 bg-muted rounded-md">{assignee?.name || 'غير معروف'}</div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="reason">سبب التأجيل</Label>
            <Textarea
              id="reason"
              placeholder="أدخل سبب طلب التأجيل"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              required
              rows={3}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="new-date">التاريخ الجديد</Label>
              <Input
                id="new-date"
                type="date"
                min={today}
                value={newDate}
                onChange={(e) => setNewDate(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="new-time">الوقت الجديد</Label>
              <Input
                id="new-time"
                type="time"
                value={newTime}
                onChange={(e) => setNewTime(e.target.value)}
                required
              />
            </div>
          </div>
          
          <DialogFooter className="mt-6">
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? 'جاري التحديث...' : 'إعادة جدولة المهمة'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default PostponeTaskModal;
