
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Paperclip, Mic, Send, Smile } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useApp } from '@/context/AppContext';

interface ChatInputProps {
  receiverId: string | null; // null for public messages
}

const EMOJIS = ['😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇', 
                '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚', 
                '👍', '👎', '👏', '🙌', '👋', '🤝', '💪', '🙏', '💯', '🎉'];

const ChatInput: React.FC<ChatInputProps> = ({ receiverId }) => {
  const { currentUser, addMessage } = useApp();
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  
  const handleSend = () => {
    if (!message.trim() || !currentUser) return;
    
    addMessage({
      senderId: currentUser.id,
      receiverId,
      content: message.trim(),
      isVoice: false,
    });
    
    setMessage('');
  };
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };
  
  const startRecording = () => {
    setIsRecording(true);
    // In a real app, we would start recording here
  };
  
  const stopRecording = () => {
    setIsRecording(false);
    // In a real app, we would stop recording and send the audio message
    
    if (currentUser) {
      addMessage({
        senderId: currentUser.id,
        receiverId,
        content: 'رسالة صوتية',
        isVoice: true,
      });
    }
  };
  
  const addEmoji = (emoji: string) => {
    setMessage(prev => prev + emoji);
  };
  
  const handleAttachment = () => {
    // This would open a file selector in a real app
    if (currentUser) {
      addMessage({
        senderId: currentUser.id,
        receiverId,
        content: 'مرفق جديد',
        attachments: ['file.pdf'],
        isVoice: false,
      });
    }
  };

  return (
    <div className="border-t p-3 bg-background">
      <div className="flex items-center space-x-2">
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="ghost" size="icon" className="flex-shrink-0">
              <Smile className="h-5 w-5" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-64 p-2">
            <div className="grid grid-cols-8 gap-1">
              {EMOJIS.map((emoji, index) => (
                <button
                  key={index}
                  onClick={() => addEmoji(emoji)}
                  className="p-1 text-lg hover:bg-muted rounded"
                >
                  {emoji}
                </button>
              ))}
            </div>
          </PopoverContent>
        </Popover>
        
        <Button 
          variant="ghost" 
          size="icon" 
          className="flex-shrink-0"
          onClick={handleAttachment}
        >
          <Paperclip className="h-5 w-5" />
        </Button>
        
        <Input
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="اكتب رسالتك هنا..."
          className="flex-1 ms-2 me-2"
        />
        
        {!isRecording ? (
          <>
            <Button 
              variant="ghost" 
              size="icon" 
              className="flex-shrink-0 ml-2 text-red-500"
              onMouseDown={startRecording}
            >
              <Mic className="h-5 w-5" />
            </Button>
            
            <Button 
              onClick={handleSend} 
              size="icon" 
              className="flex-shrink-0"
              disabled={!message.trim()}
            >
              <Send className="h-5 w-5" />
            </Button>
          </>
        ) : (
          <Button 
            variant="destructive" 
            size="sm" 
            className="flex-shrink-0 animate-pulse"
            onClick={stopRecording}
          >
            إيقاف التسجيل...
          </Button>
        )}
      </div>
    </div>
  );
};

export default ChatInput;
