
import React from 'react';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useApp, Message } from '@/context/AppContext';
import { formatDistanceToNow } from 'date-fns';
import { ar } from 'date-fns/locale';

interface ChatMessageProps {
  message: Message;
  isCurrentUser: boolean;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message, isCurrentUser }) => {
  const { getUserById } = useApp();
  const sender = getUserById(message.senderId);
  
  return (
    <div className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'} mb-4`}>
      {!isCurrentUser && (
        <Avatar className="mr-2">
          <AvatarFallback className="bg-primary text-primary-foreground">
            {sender?.name.charAt(0) || '?'}
          </AvatarFallback>
        </Avatar>
      )}
      
      <div className={`max-w-[70%] ${isCurrentUser ? 'bg-primary text-primary-foreground' : 'bg-secondary/10 text-foreground'} rounded-lg p-3`}>
        {!isCurrentUser && (
          <div className="font-medium text-xs mb-1">{sender?.name || 'مستخدم غير معروف'}</div>
        )}
        
        {message.isVoice ? (
          <div className="flex items-center">
            <span className="text-lg me-2">🎤</span>
            <audio src="#" controls className="max-w-full h-8" />
          </div>
        ) : (
          <p className="text-sm">{message.content}</p>
        )}
        
        {message.attachments && message.attachments.length > 0 && (
          <div className="mt-2 p-2 bg-black/10 rounded-md">
            <span className="text-xs">📎 مرفق: {message.attachments[0]}</span>
          </div>
        )}
        
        <div className="text-xs mt-1 opacity-70 text-right">
          {formatDistanceToNow(new Date(message.timestamp), { 
            locale: ar, 
            addSuffix: true
          })}
        </div>
      </div>
      
      {isCurrentUser && (
        <Avatar className="ml-2">
          <AvatarFallback className="bg-primary text-primary-foreground">
            {sender?.name.charAt(0) || '?'}
          </AvatarFallback>
        </Avatar>
      )}
    </div>
  );
};

export default ChatMessage;
