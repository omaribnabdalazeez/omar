
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useApp, TaskPriority } from '@/context/AppContext';
import { toast } from '@/components/ui/sonner';

interface NewTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const NewTaskModal: React.FC<NewTaskModalProps> = ({ isOpen, onClose }) => {
  const { users, currentUser, addTask } = useApp();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [dueTime, setDueTime] = useState('');
  const [priority, setPriority] = useState<TaskPriority>('متوسطة');
  const [assignedToId, setAssignedToId] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!dueDate || !dueTime) {
      toast.error('الرجاء تحديد التاريخ والوقت');
      return;
    }
    
    if (!assignedToId) {
      toast.error('الرجاء اختيار الشخص المسؤول');
      return;
    }
    
    setIsLoading(true);
    
    // Check if assigned user exists
    const assignedUser = users.find(user => user.id === assignedToId);
    if (!assignedUser) {
      toast.error('المستخدم المطلوب غير موجود');
      setIsLoading(false);
      return;
    }
    
    // Create due date from date and time inputs
    const [year, month, day] = dueDate.split('-').map(Number);
    const [hours, minutes] = dueTime.split(':').map(Number);
    const dueDateObj = new Date(year, month - 1, day, hours, minutes);
    
    // Create task
    addTask({
      title,
      description,
      dueDate: dueDateObj,
      createdBy: currentUser?.id || '',
      assignedTo: assignedToId,
      priority,
    });
    
    // Reset form and close modal
    resetForm();
    onClose();
    setIsLoading(false);
  };

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setDueDate('');
    setDueTime('');
    setPriority('متوسطة');
    setAssignedToId('');
  };

  // Format today's date as YYYY-MM-DD for the date input min attribute
  const today = new Date().toISOString().split('T')[0];

  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      if (!open) resetForm();
      onClose();
    }}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-center text-xl font-bold">إضافة مهمة جديدة</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="title">عنوان المهمة</Label>
            <Input
              id="title"
              placeholder="أدخل عنوان المهمة"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="description">تفاصيل المهمة</Label>
            <Textarea
              id="description"
              placeholder="أدخل وصف تفصيلي للمهمة"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
              rows={3}
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="due-date">تاريخ التنفيذ</Label>
              <Input
                id="due-date"
                type="date"
                min={today}
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="due-time">وقت التنفيذ</Label>
              <Input
                id="due-time"
                type="time"
                value={dueTime}
                onChange={(e) => setDueTime(e.target.value)}
                required
              />
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="priority">أهمية المهمة</Label>
            <Select 
              value={priority} 
              onValueChange={(value) => setPriority(value as TaskPriority)}
            >
              <SelectTrigger>
                <SelectValue placeholder="اختر مستوى الأهمية" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="بسيطة">بسيطة</SelectItem>
                <SelectItem value="متوسطة">متوسطة</SelectItem>
                <SelectItem value="ضرورية">ضرورية</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="assigned-to">الشخص المسؤول</Label>
            <Select 
              value={assignedToId} 
              onValueChange={setAssignedToId}
            >
              <SelectTrigger>
                <SelectValue placeholder="اختر الشخص المسؤول" />
              </SelectTrigger>
              <SelectContent>
                {users.map(user => (
                  <SelectItem key={user.id} value={user.id}>
                    {user.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <DialogFooter className="mt-6">
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? 'جاري الحفظ...' : 'حفظ المهمة'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default NewTaskModal;
