
import React, { createContext, useContext, useState, useEffect } from 'react';
import { toast } from '@/components/ui/sonner';

// Define user type
export type User = {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  points: number;
};

// Define task priority type
export type TaskPriority = 'بسيطة' | 'متوسطة' | 'ضرورية';

// Define task status type
export type TaskStatus = 'قيد التنفيذ' | 'مكتملة' | 'متأخرة' | 'مؤجلة';

// Define task type
export type Task = {
  id: string;
  title: string;
  description: string;
  dueDate: Date;
  createdBy: string;
  assignedTo: string;
  status: TaskStatus;
  priority: TaskPriority;
  createdAt: Date;
  postponeReason?: string;
  postponedUntil?: Date;
};

// Define notification type
export type Notification = {
  id: string;
  userId: string;
  taskId?: string;
  message: string;
  read: boolean;
  createdAt: Date;
  type: 'task' | 'warning' | 'achievement' | 'penalty';
};

// Define message type
export type Message = {
  id: string;
  senderId: string;
  receiverId: string | null; // null means it's a public message
  content: string;
  timestamp: Date;
  isRead: boolean;
  attachments?: string[];
  isVoice?: boolean;
};

// Define context type
type AppContextType = {
  currentUser: User | null;
  isAuthenticated: boolean;
  users: User[];
  tasks: Task[];
  notifications: Notification[];
  messages: Message[];
  onlineUsers: string[];
  login: (email: string, password: string) => boolean;
  register: (name: string, email: string, password: string) => boolean;
  logout: () => void;
  addTask: (task: Omit<Task, 'id' | 'createdAt' | 'status'>) => void;
  updateTask: (taskId: string, updates: Partial<Task>) => void;
  deleteTask: (taskId: string) => void;
  postponeTask: (taskId: string, reason: string, newDate: Date) => void;
  assignTaskToUser: (taskId: string, userId: string) => void;
  completeTask: (taskId: string) => void;
  addMessage: (message: Omit<Message, 'id' | 'timestamp' | 'isRead'>) => void;
  markNotificationAsRead: (notificationId: string) => void;
  getTasksByFilter: (filter: 'day' | 'week' | 'month' | 'year', userId?: string) => Task[];
  getUserById: (userId: string) => User | undefined;
  addNotification: (notification: Omit<Notification, 'id' | 'createdAt' | 'read'>) => void;
  deleteUser: (userId: string) => void;
};

// Create the context
const AppContext = createContext<AppContextType | undefined>(undefined);

// Create mock data
const mockUsers: User[] = [
  {
    id: '1',
    name: 'أحمد محمد',
    email: 'admin@example.com',
    role: 'admin',
    points: 120
  },
  {
    id: '2',
    name: 'محمد علي',
    email: 'user@example.com',
    role: 'user',
    points: 75
  },
  {
    id: '3',
    name: 'فاطمة أحمد',
    email: 'fatima@example.com',
    role: 'user',
    points: 90
  }
];

// Generate random tasks
const generateMockTasks = (): Task[] => {
  const priorities: TaskPriority[] = ['بسيطة', 'متوسطة', 'ضرورية'];
  const statuses: TaskStatus[] = ['قيد التنفيذ', 'مكتملة', 'متأخرة', 'مؤجلة'];
  
  return Array.from({ length: 15 }, (_, i) => ({
    id: `task-${i + 1}`,
    title: `مهمة ${i + 1}`,
    description: `وصف تفصيلي للمهمة رقم ${i + 1}`,
    dueDate: new Date(Date.now() + Math.random() * 7 * 24 * 60 * 60 * 1000),
    createdBy: mockUsers[Math.floor(Math.random() * mockUsers.length)].id,
    assignedTo: mockUsers[Math.floor(Math.random() * mockUsers.length)].id,
    status: statuses[Math.floor(Math.random() * statuses.length)],
    priority: priorities[Math.floor(Math.random() * priorities.length)],
    createdAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000),
  }));
};

// Generate mock notifications
const generateMockNotifications = (tasks: Task[]): Notification[] => {
  const types = ['task', 'warning', 'achievement', 'penalty'];
  
  return tasks.slice(0, 10).map((task, i) => ({
    id: `notif-${i + 1}`,
    userId: task.assignedTo,
    taskId: task.id,
    message: `تم تعيين مهمة "${task.title}" لك`,
    read: Math.random() > 0.5,
    createdAt: new Date(Date.now() - Math.random() * 5 * 24 * 60 * 60 * 1000),
    type: types[Math.floor(Math.random() * types.length)] as any,
  }));
};

// Generate mock messages
const generateMockMessages = (): Message[] => {
  return Array.from({ length: 20 }, (_, i) => ({
    id: `msg-${i + 1}`,
    senderId: mockUsers[Math.floor(Math.random() * mockUsers.length)].id,
    receiverId: Math.random() > 0.3 ? mockUsers[Math.floor(Math.random() * mockUsers.length)].id : null,
    content: `هذه رسالة تجريبية رقم ${i + 1}`,
    timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000),
    isRead: Math.random() > 0.5,
    attachments: Math.random() > 0.7 ? ['attachment.pdf'] : undefined,
    isVoice: Math.random() > 0.8,
  }));
};

// Custom provider component
export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Generate mock data
  const mockTasks = generateMockTasks();
  const mockNotifications = generateMockNotifications(mockTasks);
  const mockMessages = generateMockMessages();
  
  // State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [users, setUsers] = useState<User[]>(mockUsers);
  const [tasks, setTasks] = useState<Task[]>(mockTasks);
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);
  const [messages, setMessages] = useState<Message[]>(mockMessages);
  const [onlineUsers, setOnlineUsers] = useState<string[]>(['1', '3']); // Mock online users

  // Check local storage for user on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
      setIsAuthenticated(true);
    }
  }, []);

  // Login function
  const login = (email: string, password: string): boolean => {
    // In a real app, you would validate against a backend
    // Here we're just checking if the email exists in our mock data
    const user = users.find(u => u.email === email);
    
    if (user) {
      setCurrentUser(user);
      setIsAuthenticated(true);
      localStorage.setItem('currentUser', JSON.stringify(user));
      
      // Add this user to online users
      if (!onlineUsers.includes(user.id)) {
        setOnlineUsers([...onlineUsers, user.id]);
      }
      
      toast.success('تم تسجيل الدخول بنجاح');
      return true;
    }
    
    toast.error('البريد الإلكتروني أو كلمة المرور غير صحيحة');
    return false;
  };

  // Register function
  const register = (name: string, email: string, password: string): boolean => {
    // Check if email already exists
    if (users.some(u => u.email === email)) {
      toast.error('البريد الإلكتروني مستخدم بالفعل');
      return false;
    }
    
    // Create new user
    const newUser: User = {
      id: `user-${Date.now()}`,
      name,
      email,
      role: 'user', // New users are always regular users
      points: 0
    };
    
    // Update users array
    setUsers([...users, newUser]);
    
    // Automatically log in the new user
    setCurrentUser(newUser);
    setIsAuthenticated(true);
    localStorage.setItem('currentUser', JSON.stringify(newUser));
    
    // Add to online users
    setOnlineUsers([...onlineUsers, newUser.id]);
    
    toast.success('تم إنشاء الحساب بنجاح');
    return true;
  };

  // Logout function
  const logout = () => {
    // Remove from online users
    if (currentUser) {
      setOnlineUsers(onlineUsers.filter(id => id !== currentUser.id));
    }
    
    setCurrentUser(null);
    setIsAuthenticated(false);
    localStorage.removeItem('currentUser');
    toast.success('تم تسجيل الخروج بنجاح');
  };

  // Add task function
  const addTask = (task: Omit<Task, 'id' | 'createdAt' | 'status'>) => {
    // Verify that assignedTo user exists
    const assignedUser = users.find(u => u.id === task.assignedTo);
    
    if (!assignedUser) {
      toast.error('المستخدم المطلوب تنفيذ المهمة غير موجود');
      return;
    }
    
    const newTask: Task = {
      ...task,
      id: `task-${Date.now()}`,
      createdAt: new Date(),
      status: 'قيد التنفيذ',
    };
    
    setTasks([...tasks, newTask]);
    
    // Create notification for assigned user
    addNotification({
      userId: task.assignedTo,
      taskId: newTask.id,
      message: `تم تعيين مهمة جديدة لك: ${task.title}`,
      type: 'task'
    });
    
    toast.success('تم إنشاء المهمة بنجاح');
  };

  // Update task function
  const updateTask = (taskId: string, updates: Partial<Task>) => {
    const taskIndex = tasks.findIndex(t => t.id === taskId);
    
    if (taskIndex === -1) {
      toast.error('المهمة غير موجودة');
      return;
    }
    
    const updatedTasks = [...tasks];
    updatedTasks[taskIndex] = { ...updatedTasks[taskIndex], ...updates };
    setTasks(updatedTasks);
    
    // Notify the assigned user if assignment changed
    if (updates.assignedTo && updates.assignedTo !== tasks[taskIndex].assignedTo) {
      addNotification({
        userId: updates.assignedTo,
        taskId,
        message: `تم تعيين مهمة لك: ${tasks[taskIndex].title}`,
        type: 'task'
      });
    }
    
    toast.success('تم تحديث المهمة بنجاح');
  };

  // Delete task function
  const deleteTask = (taskId: string) => {
    setTasks(tasks.filter(t => t.id !== taskId));
    toast.success('تم حذف المهمة بنجاح');
  };

  // Postpone task function
  const postponeTask = (taskId: string, reason: string, newDate: Date) => {
    const taskIndex = tasks.findIndex(t => t.id === taskId);
    
    if (taskIndex === -1) {
      toast.error('المهمة غير موجودة');
      return;
    }
    
    const updatedTasks = [...tasks];
    updatedTasks[taskIndex] = { 
      ...updatedTasks[taskIndex], 
      status: 'مؤجلة',
      postponeReason: reason,
      postponedUntil: newDate,
      dueDate: newDate
    };
    
    setTasks(updatedTasks);
    
    // Notify relevant users
    addNotification({
      userId: updatedTasks[taskIndex].createdBy,
      taskId,
      message: `تم تأجيل المهمة "${updatedTasks[taskIndex].title}" إلى ${newDate.toLocaleDateString('ar-EG')}`,
      type: 'warning'
    });
    
    toast.success('تم تأجيل المهمة بنجاح');
  };

  // Assign task to user function
  const assignTaskToUser = (taskId: string, userId: string) => {
    // Verify that user exists
    const assignedUser = users.find(u => u.id === userId);
    
    if (!assignedUser) {
      toast.error('المستخدم غير موجود');
      return;
    }
    
    const taskIndex = tasks.findIndex(t => t.id === taskId);
    
    if (taskIndex === -1) {
      toast.error('المهمة غير موجودة');
      return;
    }
    
    const updatedTasks = [...tasks];
    updatedTasks[taskIndex] = { ...updatedTasks[taskIndex], assignedTo: userId };
    setTasks(updatedTasks);
    
    // Notify the new assignee
    addNotification({
      userId,
      taskId,
      message: `تم تعيين مهمة جديدة لك: ${updatedTasks[taskIndex].title}`,
      type: 'task'
    });
    
    toast.success('تم إسناد المهمة بنجاح');
  };

  // Complete task function
  const completeTask = (taskId: string) => {
    const taskIndex = tasks.findIndex(t => t.id === taskId);
    
    if (taskIndex === -1) {
      toast.error('المهمة غير موجودة');
      return;
    }
    
    const updatedTasks = [...tasks];
    updatedTasks[taskIndex] = { ...updatedTasks[taskIndex], status: 'مكتملة' };
    setTasks(updatedTasks);
    
    // Update user points
    if (currentUser) {
      const pointsToAdd = updatedTasks[taskIndex].priority === 'ضرورية' ? 10 : 
                          updatedTasks[taskIndex].priority === 'متوسطة' ? 5 : 2;
      
      const updatedUsers = [...users];
      const userIndex = users.findIndex(u => u.id === currentUser.id);
      
      if (userIndex !== -1) {
        updatedUsers[userIndex] = { 
          ...updatedUsers[userIndex], 
          points: updatedUsers[userIndex].points + pointsToAdd 
        };
        
        setUsers(updatedUsers);
        setCurrentUser(updatedUsers[userIndex]);
        localStorage.setItem('currentUser', JSON.stringify(updatedUsers[userIndex]));
      }
      
      // Create achievement notification
      addNotification({
        userId: currentUser.id,
        taskId,
        message: `أحسنت! لقد أكملت مهمة وحصلت على ${pointsToAdd} نقاط`,
        type: 'achievement'
      });
    }
    
    toast.success('تم إكمال المهمة بنجاح');
  };

  // Add message function
  const addMessage = (message: Omit<Message, 'id' | 'timestamp' | 'isRead'>) => {
    const newMessage: Message = {
      ...message,
      id: `msg-${Date.now()}`,
      timestamp: new Date(),
      isRead: false
    };
    
    setMessages([...messages, newMessage]);
    
    // If it's a private message, notify the receiver
    if (message.receiverId) {
      const sender = users.find(u => u.id === message.senderId);
      
      if (sender) {
        addNotification({
          userId: message.receiverId,
          message: `رسالة جديدة من ${sender.name}`,
          type: 'task'
        });
      }
    }
  };

  // Mark notification as read
  const markNotificationAsRead = (notificationId: string) => {
    const notifIndex = notifications.findIndex(n => n.id === notificationId);
    
    if (notifIndex !== -1) {
      const updatedNotifications = [...notifications];
      updatedNotifications[notifIndex] = { ...updatedNotifications[notifIndex], read: true };
      setNotifications(updatedNotifications);
    }
  };

  // Get tasks by filter
  const getTasksByFilter = (filter: 'day' | 'week' | 'month' | 'year', userId?: string): Task[] => {
    const now = new Date();
    let startDate: Date;
    
    switch (filter) {
      case 'day':
        startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        break;
      case 'week':
        startDate = new Date(now);
        startDate.setDate(now.getDate() - now.getDay());
        break;
      case 'month':
        startDate = new Date(now.getFullYear(), now.getMonth(), 1);
        break;
      case 'year':
        startDate = new Date(now.getFullYear(), 0, 1);
        break;
      default:
        startDate = new Date(0); // Beginning of time
    }
    
    return tasks.filter(task => {
      const taskDate = new Date(task.dueDate);
      const matchesTimeFilter = taskDate >= startDate && taskDate <= now;
      return userId ? matchesTimeFilter && task.assignedTo === userId : matchesTimeFilter;
    });
  };

  // Get user by ID
  const getUserById = (userId: string): User | undefined => {
    return users.find(u => u.id === userId);
  };

  // Add notification
  const addNotification = (notification: Omit<Notification, 'id' | 'createdAt' | 'read'>) => {
    const newNotification: Notification = {
      ...notification,
      id: `notif-${Date.now()}`,
      createdAt: new Date(),
      read: false
    };
    
    setNotifications([...notifications, newNotification]);
  };

  // Delete user
  const deleteUser = (userId: string) => {
    // Check if trying to delete the current user
    if (currentUser && currentUser.id === userId) {
      toast.error('لا يمكنك حذف حسابك أثناء تسجيل الدخول');
      return;
    }
    
    // Check if the user exists
    const userToDelete = users.find(u => u.id === userId);
    if (!userToDelete) {
      toast.error('المستخدم غير موجود');
      return;
    }
    
    // Delete the user
    setUsers(users.filter(u => u.id !== userId));
    
    // Reassign tasks
    if (tasks.some(t => t.assignedTo === userId)) {
      // Find an admin to reassign tasks to
      const admin = users.find(u => u.role === 'admin' && u.id !== userId);
      
      if (admin) {
        const updatedTasks = tasks.map(task => 
          task.assignedTo === userId ? { ...task, assignedTo: admin.id } : task
        );
        
        setTasks(updatedTasks);
        
        // Notify the admin
        addNotification({
          userId: admin.id,
          message: `تم تعيين مهام المستخدم ${userToDelete.name} إليك بعد حذف حسابه`,
          type: 'task'
        });
      }
    }
    
    // Remove from online users
    setOnlineUsers(onlineUsers.filter(id => id !== userId));
    
    toast.success('تم حذف المستخدم بنجاح');
  };

  // Create context value
  const value: AppContextType = {
    currentUser,
    isAuthenticated,
    users,
    tasks,
    notifications,
    messages,
    onlineUsers,
    login,
    register,
    logout,
    addTask,
    updateTask,
    deleteTask,
    postponeTask,
    assignTaskToUser,
    completeTask,
    addMessage,
    markNotificationAsRead,
    getTasksByFilter,
    getUserById,
    addNotification,
    deleteUser
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

// Custom hook for using the context
export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
