
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar as CalendarIcon, ArrowLeft, Filter, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useApp } from '@/context/AppContext';
import Sidebar from '@/components/Sidebar';
import UserMenu from '@/components/UserMenu';
import { format } from 'date-fns';
import { ar } from 'date-fns/locale';
import TaskCard from '@/components/TaskCard';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import PostponeTaskModal from '@/components/PostponeTaskModal';
import EditTaskModal from '@/components/EditTaskModal';
import AssignTaskModal from '@/components/AssignTaskModal';

const PostponedTasks = () => {
  const { currentUser, isAuthenticated, tasks } = useApp();
  const navigate = useNavigate();
  
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [userFilter, setUserFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('date');
  const [selectedTask, setSelectedTask] = useState<any>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isPostponeModalOpen, setIsPostponeModalOpen] = useState(false);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  
  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);
  
  // Toggle sidebar collapse
  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };
  
  // Filter postponed tasks
  const getPostponedTasks = () => {
    return tasks.filter(task => {
      const userMatches = userFilter === 'all' || task.assignedTo === userFilter;
      return task.status === 'مؤجلة' && userMatches;
    });
  };
  
  // Sort tasks based on selection
  const getSortedTasks = () => {
    const postponedTasks = getPostponedTasks();
    
    switch (sortBy) {
      case 'date':
        return [...postponedTasks].sort((a, b) => 
          new Date(a.postponedUntil || a.dueDate).getTime() - 
          new Date(b.postponedUntil || b.dueDate).getTime()
        );
      case 'priority':
        const priorityOrder = { 'ضرورية': 0, 'متوسطة': 1, 'بسيطة': 2 };
        return [...postponedTasks].sort((a, b) => 
          priorityOrder[a.priority as keyof typeof priorityOrder] - 
          priorityOrder[b.priority as keyof typeof priorityOrder]
        );
      default:
        return postponedTasks;
    }
  };
  
  // Get filtered and sorted tasks
  const filteredTasks = getSortedTasks();
  
  // Handle task actions
  const handleEditTask = (task: any) => {
    setSelectedTask(task);
    setIsEditModalOpen(true);
  };
  
  const handlePostponeTask = (task: any) => {
    setSelectedTask(task);
    setIsPostponeModalOpen(true);
  };
  
  const handleAssignTask = (task: any) => {
    setSelectedTask(task);
    setIsAssignModalOpen(true);
  };

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <Sidebar isCollapsed={isSidebarCollapsed} toggleSidebar={toggleSidebar} />
      
      {/* Main Content */}
      <div className={`flex-1 transition-all duration-300 ${isSidebarCollapsed ? 'mr-16' : 'mr-64'}`}>
        {/* Header */}
        <header className="sticky top-0 z-30 border-b bg-background p-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => navigate('/')}
                className="mr-2"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <h1 className="text-2xl font-bold">المهام المؤجلة</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              {isAuthenticated && <UserMenu />}
            </div>
          </div>
        </header>
        
        {/* Content */}
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Sidebar filters */}
            <div className="col-span-1 space-y-4">
              <Card>
                <CardContent className="pt-6">
                  <h2 className="text-lg font-medium mb-4">تصفية المهام</h2>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">تصفية حسب المستخدم</label>
                      <Select 
                        value={userFilter} 
                        onValueChange={setUserFilter}
                      >
                        <SelectTrigger>
                          <Filter className="w-4 h-4 ml-2" />
                          <SelectValue placeholder="اختر المستخدم" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">جميع المستخدمين</SelectItem>
                          {currentUser && (
                            <SelectItem value={currentUser.id}>مهامي</SelectItem>
                          )}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium mb-2">ترتيب حسب</label>
                      <Select 
                        value={sortBy} 
                        onValueChange={setSortBy}
                      >
                        <SelectTrigger>
                          <Filter className="w-4 h-4 ml-2" />
                          <SelectValue placeholder="اختر طريقة الترتيب" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="date">تاريخ الاستحقاق</SelectItem>
                          <SelectItem value="priority">الأهمية</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <h2 className="text-lg font-medium mb-2">إحصائيات التأجيل</h2>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span>إجمالي المهام المؤجلة:</span>
                      <span className="font-bold">{tasks.filter(t => t.status === 'مؤجلة').length}</span>
                    </div>
                    
                    {currentUser && (
                      <div className="flex justify-between items-center">
                        <span>مهامي المؤجلة:</span>
                        <span className="font-bold">
                          {tasks.filter(t => t.status === 'مؤجلة' && t.assignedTo === currentUser.id).length}
                        </span>
                      </div>
                    )}
                    
                    <div className="flex justify-between items-center">
                      <span>مهام مؤجلة هذا الأسبوع:</span>
                      <span className="font-bold">
                        {tasks.filter(t => {
                          const now = new Date();
                          const weekStart = new Date(now);
                          weekStart.setDate(now.getDate() - now.getDay());
                          const weekEnd = new Date(now);
                          weekEnd.setDate(weekStart.getDate() + 7);
                          
                          const taskDate = new Date(t.postponedUntil || t.dueDate);
                          
                          return t.status === 'مؤجلة' && 
                            taskDate >= weekStart && 
                            taskDate <= weekEnd;
                        }).length}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Main content - Task List */}
            <div className="col-span-1 md:col-span-3">
              <Card>
                <CardHeader>
                  <CardTitle>قائمة المهام المؤجلة</CardTitle>
                  <CardDescription>
                    {filteredTasks.length} مهمة مؤجلة
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {filteredTasks.length > 0 ? (
                    <div className="grid grid-cols-1 gap-4">
                      {filteredTasks.map(task => (
                        <div key={task.id} className="border rounded-lg p-4 bg-orange-50">
                          <TaskCard
                            task={task}
                            onEdit={currentUser?.role === 'admin' ? handleEditTask : undefined}
                            onAssign={currentUser?.role === 'admin' ? handleAssignTask : undefined}
                            onPostpone={handlePostponeTask}
                            isAdmin={currentUser?.role === 'admin'}
                          />
                          
                          {task.postponeReason && (
                            <div className="mt-4 pt-4 border-t">
                              <h4 className="font-medium mb-2 flex items-center">
                                <Clock className="w-4 h-4 mr-2" />
                                سبب التأجيل:
                              </h4>
                              <p className="text-muted-foreground">{task.postponeReason}</p>
                              
                              {task.postponedUntil && (
                                <div className="mt-2">
                                  <span className="text-sm text-muted-foreground">
                                    تم التأجيل حتى: {format(new Date(task.postponedUntil), 'eeee dd/MM/yyyy', { locale: ar })}
                                  </span>
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Clock className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                      <h3 className="text-lg font-medium mb-2">لا توجد مهام مؤجلة</h3>
                      <p className="text-muted-foreground">
                        لا توجد مهام مؤجلة في الوقت الحالي
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
      
      {/* Modals */}
      <EditTaskModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        task={selectedTask}
      />
      
      <PostponeTaskModal
        isOpen={isPostponeModalOpen}
        onClose={() => setIsPostponeModalOpen(false)}
        task={selectedTask}
      />
      
      <AssignTaskModal
        isOpen={isAssignModalOpen}
        onClose={() => setIsAssignModalOpen(false)}
        task={selectedTask}
      />
    </div>
  );
};

export default PostponedTasks;
