
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Calendar as CalendarIcon, 
  ArrowLeft, 
  Plus, 
  Filter 
} from 'lucide-react';
import { Calendar } from '@/components/ui/calendar';
import { useApp, Task } from '@/context/AppContext';
import Sidebar from '@/components/Sidebar';
import UserMenu from '@/components/UserMenu';
import NewTaskModal from '@/components/NewTaskModal';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ar } from 'date-fns/locale';
import { format, isToday, isThisWeek, isThisMonth, isThisYear } from 'date-fns';
import TaskCard from '@/components/TaskCard';
import EditTaskModal from '@/components/EditTaskModal';
import PostponeTaskModal from '@/components/PostponeTaskModal';
import AssignTaskModal from '@/components/AssignTaskModal';

const TaskSchedule = () => {
  const { 
    currentUser, 
    isAuthenticated, 
    tasks,
    getUserById
  } = useApp();
  
  const navigate = useNavigate();
  
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isNewTaskModalOpen, setIsNewTaskModalOpen] = useState(false);
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isPostponeModalOpen, setIsPostponeModalOpen] = useState(false);
  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [userFilter, setUserFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'day' | 'week' | 'month'>('day');
  
  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);
  
  // Toggle sidebar collapse
  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };
  
  // Filter tasks based on the selected date and user
  const getFilteredTasks = () => {
    if (!date) return [];
    
    return tasks.filter(task => {
      const taskDate = new Date(task.dueDate);
      
      // Check if the task date matches the filter criteria
      const dateMatches = viewMode === 'day' ? isToday(taskDate) : 
                       viewMode === 'week' ? isThisWeek(taskDate) : 
                       viewMode === 'month' ? isThisMonth(taskDate) : 
                       isThisYear(taskDate);
      
      // Check if the user matches the filter criteria
      const userMatches = userFilter === 'all' || task.assignedTo === userFilter;
      
      return dateMatches && userMatches;
    });
  };
  
  // Get filtered tasks
  const filteredTasks = getFilteredTasks();
  
  // Get tasks for the selected date
  const getTasksForDate = (date: Date) => {
    return tasks.filter(task => {
      const taskDate = new Date(task.dueDate);
      return (
        taskDate.getDate() === date.getDate() &&
        taskDate.getMonth() === date.getMonth() &&
        taskDate.getFullYear() === date.getFullYear()
      );
    });
  };
  
  // Handle task actions
  const handleEditTask = (task: Task) => {
    setSelectedTask(task);
    setIsEditModalOpen(true);
  };
  
  const handlePostponeTask = (task: Task) => {
    setSelectedTask(task);
    setIsPostponeModalOpen(true);
  };
  
  const handleAssignTask = (task: Task) => {
    setSelectedTask(task);
    setIsAssignModalOpen(true);
  };
  
  // Calculate hours with tasks for the day view
  const hoursWithTasks = Array.from({ length: 24 }, (_, hour) => {
    if (!date) return { hour, tasks: [] };
    
    const tasksAtHour = tasks.filter(task => {
      const taskDate = new Date(task.dueDate);
      return (
        taskDate.getDate() === date.getDate() &&
        taskDate.getMonth() === date.getMonth() &&
        taskDate.getFullYear() === date.getFullYear() &&
        taskDate.getHours() === hour
      );
    });
    
    return { hour, tasks: tasksAtHour };
  });

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <Sidebar isCollapsed={isSidebarCollapsed} toggleSidebar={toggleSidebar} />
      
      {/* Main Content */}
      <div className={`flex-1 transition-all duration-300 ${isSidebarCollapsed ? 'mr-16' : 'mr-64'}`}>
        {/* Header */}
        <header className="sticky top-0 z-30 border-b bg-background p-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => navigate('/')}
                className="mr-2"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <h1 className="text-2xl font-bold">جدول المهام</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              {isAuthenticated && (
                <>
                  <Button onClick={() => setIsNewTaskModalOpen(true)} className="flex items-center">
                    <Plus className="ml-2 h-4 w-4" />
                    مهمة جديدة
                  </Button>
                  
                  <UserMenu />
                </>
              )}
            </div>
          </div>
        </header>
        
        {/* Main Content */}
        <div className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Filters and Calendar */}
            <div className="col-span-1 space-y-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="mb-4">
                    <h2 className="text-lg font-medium mb-2">عرض حسب</h2>
                    <Select 
                      value={viewMode} 
                      onValueChange={(value) => setViewMode(value as 'day' | 'week' | 'month')}
                    >
                      <SelectTrigger>
                        <Filter className="w-4 h-4 ml-2" />
                        <SelectValue placeholder="اختر طريقة العرض" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="day">يومي</SelectItem>
                        <SelectItem value="week">أسبوعي</SelectItem>
                        <SelectItem value="month">شهري</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="mb-4">
                    <h2 className="text-lg font-medium mb-2">تصفية حسب المستخدم</h2>
                    <Select 
                      value={userFilter} 
                      onValueChange={setUserFilter}
                    >
                      <SelectTrigger>
                        <Filter className="w-4 h-4 ml-2" />
                        <SelectValue placeholder="اختر المستخدم" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">جميع المستخدمين</SelectItem>
                        {currentUser && (
                          <SelectItem value={currentUser.id}>مهامي</SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <h2 className="text-lg font-medium mb-2">التقويم</h2>
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      className="mx-auto p-3 pointer-events-auto bg-white"
                      locale={ar}
                      disabled={(date) => date < new Date("2020-01-01")}
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <h2 className="text-lg font-medium mb-2">إحصائيات</h2>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span>إجمالي المهام:</span>
                      <span className="font-bold">{tasks.length}</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span>مهام مكتملة:</span>
                      <span className="font-bold">{tasks.filter(t => t.status === 'مكتملة').length}</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span>مهام قيد التنفيذ:</span>
                      <span className="font-bold">{tasks.filter(t => t.status === 'قيد التنفيذ').length}</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span>مهام متأخرة:</span>
                      <span className="font-bold">{tasks.filter(t => t.status === 'متأخرة').length}</span>
                    </div>
                    
                    <div className="flex justify-between items-center">
                      <span>مهام مؤجلة:</span>
                      <span className="font-bold">{tasks.filter(t => t.status === 'مؤجلة').length}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Schedule View */}
            <div className="col-span-1 lg:col-span-3">
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-xl font-bold mb-4">
                    {viewMode === 'day' && date && `جدول اليوم: ${format(date, 'eeee dd/MM/yyyy', { locale: ar })}`}
                    {viewMode === 'week' && 'جدول الأسبوع'}
                    {viewMode === 'month' && date && `جدول الشهر: ${format(date, 'MMMM yyyy', { locale: ar })}`}
                  </h2>
                  
                  {viewMode === 'day' && (
                    <div className="space-y-6">
                      {hoursWithTasks.map(({ hour, tasks }) => (
                        <div key={hour} className="border-b pb-2 last:border-b-0">
                          <div className="flex items-center mb-2">
                            <span className="font-bold w-16">{hour}:00</span>
                            <div className="flex-1 border-t border-dashed"></div>
                          </div>
                          
                          {tasks.length > 0 ? (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mr-16">
                              {tasks.map(task => (
                                <TaskCard
                                  key={task.id}
                                  task={task}
                                  onEdit={currentUser?.role === 'admin' ? handleEditTask : undefined}
                                  onAssign={currentUser?.role === 'admin' ? handleAssignTask : undefined}
                                  onPostpone={handlePostponeTask}
                                  isAdmin={currentUser?.role === 'admin'}
                                />
                              ))}
                            </div>
                          ) : (
                            <div className="mr-16 text-muted-foreground text-sm italic">
                              لا توجد مهام في هذا الوقت
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {viewMode !== 'day' && (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {filteredTasks.length > 0 ? (
                        filteredTasks.map(task => (
                          <TaskCard
                            key={task.id}
                            task={task}
                            onEdit={currentUser?.role === 'admin' ? handleEditTask : undefined}
                            onAssign={currentUser?.role === 'admin' ? handleAssignTask : undefined}
                            onPostpone={handlePostponeTask}
                            isAdmin={currentUser?.role === 'admin'}
                          />
                        ))
                      ) : (
                        <div className="col-span-full text-center py-8">
                          <CalendarIcon className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                          <h3 className="text-lg font-medium mb-2">لا توجد مهام</h3>
                          <p className="text-muted-foreground mb-4">
                            لا توجد مهام مجدولة في الفترة المحددة
                          </p>
                          <Button onClick={() => setIsNewTaskModalOpen(true)}>
                            إضافة مهمة جديدة
                          </Button>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
      
      {/* Modals */}
      <NewTaskModal 
        isOpen={isNewTaskModalOpen}
        onClose={() => setIsNewTaskModalOpen(false)}
      />
      
      <EditTaskModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        task={selectedTask}
      />
      
      <PostponeTaskModal
        isOpen={isPostponeModalOpen}
        onClose={() => setIsPostponeModalOpen(false)}
        task={selectedTask}
      />
      
      <AssignTaskModal
        isOpen={isAssignModalOpen}
        onClose={() => setIsAssignModalOpen(false)}
        task={selectedTask}
      />
    </div>
  );
};

export default TaskSchedule;
