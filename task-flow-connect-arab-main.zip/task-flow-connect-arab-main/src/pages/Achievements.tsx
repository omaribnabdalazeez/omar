
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Award, Medal, Star, Trophy, Gift } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useApp } from '@/context/AppContext';
import Sidebar from '@/components/Sidebar';
import UserMenu from '@/components/UserMenu';

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  progress: number;
  maxValue: number;
  completed: boolean;
  pointsReward: number;
}

const Achievements = () => {
  const { currentUser, isAuthenticated, tasks } = useApp();
  const navigate = useNavigate();
  
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  
  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);
  
  // Toggle sidebar collapse
  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };
  
  // Calculate user achievements based on tasks
  const getUserAchievements = (): Achievement[] => {
    if (!currentUser) return [];
    
    const completedTasks = tasks.filter(t => t.assignedTo === currentUser.id && t.status === 'مكتملة');
    const completedUrgentTasks = completedTasks.filter(t => t.priority === 'ضرورية');
    const completedTasksCount = completedTasks.length;
    
    return [
      {
        id: 'first-task',
        title: 'المهمة الأولى',
        description: 'قم بإكمال مهمة واحدة',
        icon: <Star className="w-8 h-8 text-yellow-500" />,
        progress: Math.min(completedTasksCount, 1),
        maxValue: 1,
        completed: completedTasksCount >= 1,
        pointsReward: 5
      },
      {
        id: 'productive',
        title: 'إنتاجية عالية',
        description: 'قم بإكمال 10 مهام',
        icon: <Medal className="w-8 h-8 text-blue-500" />,
        progress: Math.min(completedTasksCount, 10),
        maxValue: 10,
        completed: completedTasksCount >= 10,
        pointsReward: 20
      },
      {
        id: 'expert',
        title: 'خبير المهام',
        description: 'قم بإكمال 25 مهمة',
        icon: <Trophy className="w-8 h-8 text-amber-500" />,
        progress: Math.min(completedTasksCount, 25),
        maxValue: 25,
        completed: completedTasksCount >= 25,
        pointsReward: 50
      },
      {
        id: 'urgent-hero',
        title: 'بطل المهام الضرورية',
        description: 'قم بإكمال 5 مهام ضرورية',
        icon: <Award className="w-8 h-8 text-red-500" />,
        progress: Math.min(completedUrgentTasks.length, 5),
        maxValue: 5,
        completed: completedUrgentTasks.length >= 5,
        pointsReward: 30
      }
    ];
  };
  
  const achievements = getUserAchievements();
  const totalPoints = currentUser?.points || 0;
  const completedAchievements = achievements.filter(a => a.completed).length;
  const totalAchievements = achievements.length;
  
  // Define rewards based on points
  const rewards = [
    { 
      points: 50, 
      title: 'شهادة تقدير', 
      description: 'شهادة تقدير إلكترونية للإنجازات', 
      icon: <Gift className="w-8 h-8 text-purple-500" />,
      available: totalPoints >= 50
    },
    { 
      points: 100, 
      title: 'قسيمة هدية', 
      description: 'قسيمة هدية بقيمة 50 ريال', 
      icon: <Gift className="w-8 h-8 text-green-500" />,
      available: totalPoints >= 100
    },
    { 
      points: 200, 
      title: 'يوم إجازة مدفوع', 
      description: 'يوم إجازة إضافي مدفوع الأجر', 
      icon: <Gift className="w-8 h-8 text-blue-500" />,
      available: totalPoints >= 200
    },
  ];

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <Sidebar isCollapsed={isSidebarCollapsed} toggleSidebar={toggleSidebar} />
      
      {/* Main Content */}
      <div className={`flex-1 transition-all duration-300 ${isSidebarCollapsed ? 'mr-16' : 'mr-64'}`}>
        {/* Header */}
        <header className="sticky top-0 z-30 border-b bg-background p-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => navigate('/')}
                className="mr-2"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <h1 className="text-2xl font-bold">الإنجازات والمكافآت</h1>
            </div>
            
            <div className="flex items-center space-x-4">
              {isAuthenticated && <UserMenu />}
            </div>
          </div>
        </header>
        
        {/* Content */}
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* User stats card */}
            <div className="col-span-1 md:col-span-3">
              <Card className="bg-gradient-to-r from-purple-500 to-blue-500 text-white">
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center">
                      <h3 className="text-2xl font-bold">{totalPoints}</h3>
                      <p className="text-white/80">النقاط المكتسبة</p>
                    </div>
                    
                    <div className="text-center">
                      <h3 className="text-2xl font-bold">{completedAchievements}/{totalAchievements}</h3>
                      <p className="text-white/80">الإنجازات المكتملة</p>
                    </div>
                    
                    <div className="text-center">
                      <h3 className="text-2xl font-bold">{tasks.filter(t => t.assignedTo === currentUser?.id && t.status === 'مكتملة').length}</h3>
                      <p className="text-white/80">المهام المكتملة</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Achievements */}
            <div className="col-span-1 md:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Trophy className="mr-2 h-5 w-5 text-yellow-500" />
                    الإنجازات
                  </CardTitle>
                  <CardDescription>
                    أكمل المهام واربح النقاط والمكافآت
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {achievements.map(achievement => (
                      <div 
                        key={achievement.id} 
                        className={`p-4 border rounded-lg ${achievement.completed ? 'bg-green-50 border-green-200' : 'bg-gray-50'}`}
                      >
                        <div className="flex items-center mb-2">
                          <div className="mr-4 flex-shrink-0">
                            {achievement.icon}
                          </div>
                          
                          <div className="flex-1">
                            <h3 className="text-lg font-medium">{achievement.title}</h3>
                            <p className="text-muted-foreground text-sm">{achievement.description}</p>
                          </div>
                          
                          <div className="flex-shrink-0 text-right">
                            <div className="text-xl font-bold text-primary">
                              +{achievement.pointsReward}
                            </div>
                            <div className="text-xs text-muted-foreground">نقطة</div>
                          </div>
                        </div>
                        
                        <div className="mt-2">
                          <div className="flex justify-between text-sm mb-1">
                            <span>{achievement.progress} / {achievement.maxValue}</span>
                            <span>{Math.round((achievement.progress / achievement.maxValue) * 100)}%</span>
                          </div>
                          <Progress value={(achievement.progress / achievement.maxValue) * 100} className="h-2" />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Rewards */}
            <div className="col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Gift className="mr-2 h-5 w-5 text-pink-500" />
                    المكافآت المتاحة
                  </CardTitle>
                  <CardDescription>
                    استبدل نقاطك بمكافآت قيمة
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {rewards.map((reward, index) => (
                      <div 
                        key={index} 
                        className={`p-4 border rounded-lg ${reward.available ? 'bg-blue-50 border-blue-200' : 'bg-gray-50 opacity-60'}`}
                      >
                        <div className="flex items-center">
                          <div className="mr-4 flex-shrink-0">
                            {reward.icon}
                          </div>
                          
                          <div className="flex-1">
                            <h3 className="text-lg font-medium">{reward.title}</h3>
                            <p className="text-muted-foreground text-sm">{reward.description}</p>
                          </div>
                        </div>
                        
                        <div className="mt-2 flex justify-between items-center">
                          <div className="text-sm text-muted-foreground">
                            {reward.points} نقطة
                          </div>
                          
                          <Button 
                            size="sm" 
                            variant={reward.available ? "default" : "outline"}
                            disabled={!reward.available}
                          >
                            {reward.available ? 'استبدال' : `متبقي ${reward.points - totalPoints} نقطة`}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Achievements;
