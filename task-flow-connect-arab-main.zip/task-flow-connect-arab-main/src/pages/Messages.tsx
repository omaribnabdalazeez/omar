
import React, { useState, useEffect, useRef } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Avatar, 
  AvatarFallback 
} from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useApp, Message } from '@/context/AppContext';
import { 
  Video, 
  Phone, 
  Users, 
  MessageSquare, 
  Bell,
  ArrowLeft
} from 'lucide-react';
import ChatMessage from '@/components/ChatMessage';
import ChatInput from '@/components/ChatInput';
import Sidebar from '@/components/Sidebar';
import UserMenu from '@/components/UserMenu';
import { useNavigate } from 'react-router-dom';

const MessagesPage = () => {
  const { 
    currentUser, 
    isAuthenticated, 
    messages, 
    users, 
    onlineUsers 
  } = useApp();
  
  const navigate = useNavigate();
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [activeChatUserId, setActiveChatUserId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('private');
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);

  // Filter messages based on active chat and tab
  const filteredMessages = messages.filter(message => {
    if (activeTab === 'public') {
      return message.receiverId === null;
    }
    
    if (activeTab === 'private' && activeChatUserId) {
      return (
        (message.senderId === currentUser?.id && message.receiverId === activeChatUserId) ||
        (message.receiverId === currentUser?.id && message.senderId === activeChatUserId)
      );
    }
    
    if (activeTab === 'announcements') {
      // Announcements are from admin to everyone
      const adminIds = users.filter(u => u.role === 'admin').map(u => u.id);
      return adminIds.includes(message.senderId) && message.receiverId === null;
    }
    
    return false;
  });
  
  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [filteredMessages]);
  
  // Filter users for private chats (exclude current user)
  const chatUsers = users.filter(user => user.id !== currentUser?.id);
  
  // Toggle sidebar collapse
  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };

  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <Sidebar isCollapsed={isSidebarCollapsed} toggleSidebar={toggleSidebar} />
      
      {/* Main Content */}
      <div className={`flex-1 transition-all duration-300 ${isSidebarCollapsed ? 'mr-16' : 'mr-64'}`}>
        {/* Header */}
        <header className="sticky top-0 z-30 border-b bg-background p-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => navigate('/')}
                className="mr-2"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <h1 className="text-2xl font-bold">المحادثات</h1>
            </div>
            
            {isAuthenticated && <UserMenu />}
          </div>
        </header>
        
        {/* Messages Content */}
        <main className="p-6">
          <Tabs defaultValue="private" onValueChange={setActiveTab} value={activeTab}>
            <div className="flex justify-between items-center mb-6">
              <TabsList>
                <TabsTrigger value="private">محادثات خاصة</TabsTrigger>
                <TabsTrigger value="public">المحادثة العامة</TabsTrigger>
                <TabsTrigger value="announcements">إشعارات الإدارة</TabsTrigger>
              </TabsList>
              
              <div className="flex space-x-2">
                <Button variant="outline" size="sm" className="ml-2">
                  <Phone className="h-4 w-4 ml-2" />
                  اتصال صوتي
                </Button>
                <Button variant="outline" size="sm">
                  <Video className="h-4 w-4 ml-2" />
                  اتصال مرئي
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {/* Contacts/Chats List */}
              <div className="md:col-span-1">
                <Card className="h-[calc(100vh-13rem)] overflow-hidden">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-lg">
                        {activeTab === 'private' ? 'جهات الاتصال' : 
                         activeTab === 'public' ? 'المحادثة العامة' : 'الإشعارات'}
                      </CardTitle>
                      
                      {activeTab === 'private' && (
                        <Badge variant="outline" className="ml-2 bg-primary/10">
                          <Users className="h-3 w-3 ml-1" />
                          {onlineUsers.length}
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  
                  <div className="overflow-y-auto h-full">
                    {activeTab === 'private' ? (
                      <div className="divide-y">
                        {chatUsers.map(user => (
                          <div 
                            key={user.id}
                            onClick={() => setActiveChatUserId(user.id)}
                            className={`flex items-center p-3 cursor-pointer hover:bg-muted/50 transition-colors
                              ${activeChatUserId === user.id ? 'bg-muted' : ''}
                            `}
                          >
                            <Avatar className="ml-3">
                              <AvatarFallback className={`
                                ${onlineUsers.includes(user.id) ? 'bg-green-500' : 'bg-gray-500'}
                                text-white
                              `}>
                                {user.name.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                            
                            <div className="flex-1 overflow-hidden">
                              <div className="flex justify-between items-center">
                                <span className="font-medium truncate">{user.name}</span>
                                
                                {onlineUsers.includes(user.id) && (
                                  <Badge variant="outline" className="bg-green-500/10 text-green-500 text-xs">
                                    متصل
                                  </Badge>
                                )}
                              </div>
                              
                              <p className="text-sm text-muted-foreground truncate">
                                {user.role === 'admin' ? 'مدير النظام' : 'مستخدم'}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : activeTab === 'public' ? (
                      <div className="p-4">
                        <div className="flex items-center mb-4">
                          <Avatar className="ml-3">
                            <AvatarFallback className="bg-primary text-primary-foreground">
                              <Users className="h-4 w-4" />
                            </AvatarFallback>
                          </Avatar>
                          
                          <div>
                            <h3 className="font-medium">المحادثة العامة</h3>
                            <p className="text-xs text-muted-foreground">
                              {onlineUsers.length} متصل الآن
                            </p>
                          </div>
                        </div>
                        
                        <p className="text-sm text-muted-foreground p-3 bg-muted/50 rounded-md">
                          هذه محادثة عامة يمكن لجميع المستخدمين المشاركة فيها ورؤية الرسائل.
                        </p>
                      </div>
                    ) : (
                      <div className="p-4">
                        <div className="flex items-center mb-4">
                          <Avatar className="ml-3">
                            <AvatarFallback className="bg-primary text-primary-foreground">
                              <Bell className="h-4 w-4" />
                            </AvatarFallback>
                          </Avatar>
                          
                          <div>
                            <h3 className="font-medium">إشعارات الإدارة</h3>
                            <p className="text-xs text-muted-foreground">
                              إعلانات وتنبيهات رسمية
                            </p>
                          </div>
                        </div>
                        
                        <p className="text-sm text-muted-foreground p-3 bg-muted/50 rounded-md">
                          تحتوي هذه القائمة على الإشعارات الرسمية من إدارة النظام.
                        </p>
                      </div>
                    )}
                  </div>
                </Card>
              </div>
              
              {/* Chat Area */}
              <div className="md:col-span-3">
                <Card className="h-[calc(100vh-13rem)] flex flex-col">
                  <CardHeader className="pb-2 border-b">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <Avatar className="ml-3">
                          <AvatarFallback className="bg-primary text-primary-foreground">
                            {activeTab === 'private' && activeChatUserId 
                              ? users.find(u => u.id === activeChatUserId)?.name.charAt(0) || '?'
                              : activeTab === 'public' 
                                ? <Users className="h-4 w-4" />
                                : <Bell className="h-4 w-4" />
                            }
                          </AvatarFallback>
                        </Avatar>
                        
                        <div>
                          <CardTitle className="text-lg">
                            {activeTab === 'private' && activeChatUserId 
                              ? users.find(u => u.id === activeChatUserId)?.name || 'محادثة خاصة'
                              : activeTab === 'public' 
                                ? 'المحادثة العامة'
                                : 'إشعارات الإدارة'
                            }
                          </CardTitle>
                          
                          {activeTab === 'private' && activeChatUserId && onlineUsers.includes(activeChatUserId) && (
                            <p className="text-xs text-green-500">متصل الآن</p>
                          )}
                        </div>
                      </div>
                      
                      {activeTab === 'private' && activeChatUserId && (
                        <div className="flex space-x-2">
                          <Button variant="ghost" size="icon">
                            <Phone className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="icon">
                            <Video className="h-4 w-4" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardHeader>
                  
                  <CardContent className="flex-1 overflow-y-auto p-4">
                    {filteredMessages.length > 0 ? (
                      <div className="space-y-4">
                        {filteredMessages.map(message => (
                          <ChatMessage
                            key={message.id}
                            message={message}
                            isCurrentUser={message.senderId === currentUser?.id}
                          />
                        ))}
                        <div ref={messagesEndRef} />
                      </div>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full text-center">
                        <MessageSquare className="h-12 w-12 text-muted-foreground mb-4" />
                        <h3 className="text-lg font-medium">لا توجد رسائل</h3>
                        <p className="text-sm text-muted-foreground mt-1">
                          {activeTab === 'private' && activeChatUserId 
                            ? 'ابدأ محادثة جديدة مع هذا المستخدم'
                            : activeTab === 'public' 
                              ? 'كن أول من يبدأ المحادثة العامة'
                              : 'لا توجد إشعارات من الإدارة حالياً'
                          }
                        </p>
                      </div>
                    )}
                  </CardContent>
                  
                  {/* Only show input for private chats and public chat */}
                  {(activeTab === 'private' && activeChatUserId) || activeTab === 'public' ? (
                    <ChatInput 
                      receiverId={activeTab === 'private' ? activeChatUserId : null} 
                    />
                  ) : activeTab === 'announcements' && currentUser?.role === 'admin' ? (
                    <ChatInput receiverId={null} />
                  ) : null}
                </Card>
              </div>
            </div>
          </Tabs>
        </main>
      </div>
    </div>
  );
};

export default MessagesPage;
