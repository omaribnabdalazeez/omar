import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ChevronDown,
  Plus
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useApp } from '@/context/AppContext';
import Sidebar from '@/components/Sidebar';
import UserMenu from '@/components/UserMenu';
import LoginModal from '@/components/LoginModal';
import SubscriptionModal from '@/components/SubscriptionModal';
import TaskCardWrapper from '@/components/TaskCardWrapper';
import AddTaskModal from '@/components/AddTaskModal';

const DailyTasks = () => {
  const { 
    currentUser, 
    isAuthenticated, 
    tasks, 
    users,
    getTasksByFilter
  } = useApp();
  
  const navigate = useNavigate();
  
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [filterPeriod, setFilterPeriod] = useState<'day' | 'week' | 'month'>('day');
  const [filterUser, setFilterUser] = useState<string | null>(null);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState(false);
  const [isAddTaskModalOpen, setIsAddTaskModalOpen] = useState(false);
  
  // Toggle sidebar collapse
  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };
  
  // Filter tasks by period
  const filteredTasks = getTasksByFilter(filterPeriod, filterUser || undefined);
  
  // Updated render function
  return (
    <div className="flex min-h-screen bg-background">
      {/* Sidebar */}
      <Sidebar isCollapsed={isSidebarCollapsed} toggleSidebar={toggleSidebar} />
      
      {/* Main Content */}
      <div className={`flex-1 transition-all duration-300 ${isSidebarCollapsed ? 'mr-16' : 'mr-64'}`}>
        {/* Header */}
        <header className="sticky top-0 z-30 border-b bg-background p-4">
          <div className="flex justify-between items-center">
            <div className="flex-1"></div>
            
            <h1 className="text-2xl font-bold flex-1 text-center">المهام اليومية</h1>
            
            <div className="flex items-center space-x-4 flex-1 justify-end">
              {isAuthenticated ? (
                <UserMenu />
              ) : (
                <Button onClick={() => setIsLoginModalOpen(true)}>
                  تسجيل الدخول
                </Button>
              )}
            </div>
          </div>
        </header>
        
        {/* Content */}
        <div className="p-6">
          {/* Filter controls */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-semibold">مهام اليوم</h2>
              <span className="text-muted-foreground">
                {new Date().toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
              </span>
            </div>
            
            <div className="flex flex-wrap gap-2">
              {isAuthenticated && (
                <Button onClick={() => setIsAddTaskModalOpen(true)} className="flex items-center gap-2">
                  <Plus size={16} />
                  <span>إضافة مهمة</span>
                </Button>
              )}
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="flex items-center gap-2">
                    تصفية <ChevronDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => setFilterPeriod('day')}>
                    اليوم
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setFilterPeriod('week')}>
                    هذا الأسبوع
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setFilterPeriod('month')}>
                    هذا الشهر
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              {isAuthenticated && (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" className="flex items-center gap-2">
                      المستخدم <ChevronDown className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => setFilterUser(currentUser?.id)}>
                      مهامي
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setFilterUser(null)}>
                      جميع المهام
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          </div>
          
          {/* Tasks grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTasks.length > 0 ? (
              filteredTasks.map(task => (
                <TaskCardWrapper 
                  key={task.id} 
                  task={task}
                  assigneeName={users.find(u => u.id === task.assignedTo)?.name || 'مستخدم غير معروف'}
                  creatorName={users.find(u => u.id === task.createdBy)?.name || 'مستخدم غير معروف'} 
                />
              ))
            ) : (
              <div className="col-span-full text-center p-8">
                <p className="text-muted-foreground">لا توجد مهام في هذه الفترة</p>
                {isAuthenticated && (
                  <Button onClick={() => setIsAddTaskModalOpen(true)} className="mt-4">
                    إضافة مهمة جديدة
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Modals */}
      <LoginModal 
        isOpen={isLoginModalOpen} 
        onClose={() => setIsLoginModalOpen(false)} 
        onRegisterClick={() => {
          setIsLoginModalOpen(false);
          setIsSubscriptionModalOpen(true);
        }} 
      />
      
      <SubscriptionModal 
        isOpen={isSubscriptionModalOpen} 
        onClose={() => setIsSubscriptionModalOpen(false)} 
      />
      
      <AddTaskModal 
        isOpen={isAddTaskModalOpen} 
        onClose={() => setIsAddTaskModalOpen(false)} 
      />
    </div>
  );
};

export default DailyTasks;
