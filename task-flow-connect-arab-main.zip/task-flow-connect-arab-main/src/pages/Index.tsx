import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ChevronDown, 
  CheckCircle, 
  Clock, 
  AlertCircle, 
  Calendar, 
  MessageCircle,
  Users,
  Award,
  Bell
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { useApp } from '@/context/AppContext';
import TaskCardWrapper from '@/components/TaskCardWrapper';
import Sidebar from '@/components/Sidebar';
import UserMenu from '@/components/UserMenu';
import SubscriptionModal from '@/components/SubscriptionModal';
import LoginModal from '@/components/LoginModal';

const Index = () => {
  const { 
    currentUser, 
    isAuthenticated, 
    tasks, 
    users,
    getTasksByFilter
  } = useApp();
  
  const navigate = useNavigate();
  
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [filterPeriod, setFilterPeriod] = useState<'day' | 'week' | 'month' | 'year'>('day');
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  
  const toggleSidebar = () => {
    setIsSidebarCollapsed(!isSidebarCollapsed);
  };
  
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(task => task.status === 'مكتملة').length;
  const inProgressTasks = tasks.filter(task => task.status === 'قيد التنفيذ').length;
  const delayedTasks = tasks.filter(task => task.status === 'متأخرة').length;
  
  const filteredTasks = getTasksByFilter(filterPeriod);
  
  const userTasks = isAuthenticated && currentUser 
    ? tasks.filter(task => task.assignedTo === currentUser.id && task.status === 'قيد التنفيذ') 
    : [];
  
  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar isCollapsed={isSidebarCollapsed} toggleSidebar={toggleSidebar} />
      
      <div className={`flex-1 transition-all duration-300 ${isSidebarCollapsed ? 'mr-16' : 'mr-64'}`}>
        <header className="sticky top-0 z-30 border-b bg-background p-4">
          <div className="flex justify-between items-center">
            <div className="flex-1"></div>
            
            <h1 className="text-2xl font-bold flex-1 text-center">نظام إدارة المهام</h1>
            
            <div className="flex items-center space-x-4 flex-1 justify-end">
              {isAuthenticated ? (
                <UserMenu />
              ) : (
                <>
                  <Button variant="outline" onClick={() => setIsLoginModalOpen(true)}>
                    تسجيل الدخول
                  </Button>
                  <Button onClick={() => setIsSubscriptionModalOpen(true)}>
                    اشترك الآن
                  </Button>
                </>
              )}
            </div>
          </div>
        </header>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center justify-between">
                  المهام الكلية
                  <div className="rounded-full bg-blue-100 p-2">
                    <Calendar className="h-4 w-4 text-blue-500" />
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalTasks}</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center justify-between">
                  المهام المكتملة
                  <div className="rounded-full bg-green-100 p-2">
                    <CheckCircle className="h-4 w-4 text-green-500" />
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{completedTasks}</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center justify-between">
                  قيد التنفيذ
                  <div className="rounded-full bg-yellow-100 p-2">
                    <Clock className="h-4 w-4 text-yellow-500" />
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{inProgressTasks}</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium flex items-center justify-between">
                  المهام المتأخرة
                  <div className="rounded-full bg-red-100 p-2">
                    <AlertCircle className="h-4 w-4 text-red-500" />
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{delayedTasks}</div>
              </CardContent>
            </Card>
          </div>
          
          <div className="mb-6 flex justify-between items-center">
            <h2 className="text-xl font-semibold">عرض المهام</h2>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="flex items-center gap-2">
                  تصفية <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setFilterPeriod('day')}>
                  اليوم
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterPeriod('week')}>
                  هذا الأسبوع
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterPeriod('month')}>
                  هذا الشهر
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setFilterPeriod('year')}>
                  هذا العام
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          
          <Tabs defaultValue="all" className="mb-8">
            <TabsList className="mb-4">
              <TabsTrigger value="all">جميع المهام</TabsTrigger>
              <TabsTrigger value="user">المهام اليومية</TabsTrigger>
            </TabsList>
            
            <TabsContent value="all">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredTasks.length > 0 ? (
                  filteredTasks.map(task => (
                    <TaskCardWrapper 
                      key={task.id} 
                      task={task}
                      assigneeName={users.find(u => u.id === task.assignedTo)?.name || 'مستخدم غير معروف'}
                      creatorName={users.find(u => u.id === task.createdBy)?.name || 'مستخدم غير معروف'} 
                    />
                  ))
                ) : (
                  <div className="col-span-full text-center p-8">
                    <p className="text-muted-foreground">لا توجد مهام خلال هذه الفترة</p>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="user">
              {isAuthenticated ? (
                userTasks.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {userTasks.map(task => (
                      <TaskCardWrapper 
                        key={task.id} 
                        task={task}
                        assigneeName={users.find(u => u.id === task.assignedTo)?.name || 'مستخدم غير معروف'}
                        creatorName={users.find(u => u.id === task.createdBy)?.name || 'مستخدم غير معروف'} 
                      />
                    ))}
                  </div>
                ) : (
                  <div className="text-center p-8">
                    <p className="text-muted-foreground">ليس لديك مهام حالية</p>
                  </div>
                )
              ) : (
                <div className="text-center p-8">
                  <p className="text-muted-foreground mb-4">يرجى تسجيل الدخول لعرض المهام اليومية الخاصة بك</p>
                  <Button onClick={() => setIsLoginModalOpen(true)}>
                    تسجيل الدخول
                  </Button>
                </div>
              )}
            </TabsContent>
          </Tabs>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Button 
              variant="outline" 
              className="h-auto p-6 flex flex-col items-center gap-2"
              onClick={() => navigate('/daily-tasks')}
            >
              <Calendar className="h-8 w-8" />
              <span>المهام اليومية</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-auto p-6 flex flex-col items-center gap-2"
              onClick={() => navigate('/messages')}
            >
              <MessageCircle className="h-8 w-8" />
              <span>المحادثات</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-auto p-6 flex flex-col items-center gap-2"
              onClick={() => navigate('/task-schedule')}
            >
              <Users className="h-8 w-8" />
              <span>جدول المهام</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="h-auto p-6 flex flex-col items-center gap-2"
              onClick={() => navigate('/achievements')}
            >
              <Award className="h-8 w-8" />
              <span>الإنجازات</span>
            </Button>
          </div>
        </div>
      </div>
      
      <SubscriptionModal 
        isOpen={isSubscriptionModalOpen} 
        onClose={() => setIsSubscriptionModalOpen(false)} 
      />
      
      <LoginModal 
        isOpen={isLoginModalOpen} 
        onClose={() => setIsLoginModalOpen(false)} 
        onRegisterClick={() => {
          setIsLoginModalOpen(false);
          setIsSubscriptionModalOpen(true);
        }} 
      />
    </div>
  );
};

export default Index;
